"""UEBA URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path("admin/", admin.site.urls),
]

urlpatterns = [
    path('', views.index, name='index'),
    path('mubina/', views.mubina, name='mubina'),
    path('mubina_Login_after_hours_All_user/', views.mubina_Login_after_hours_All_user, name='mubina_Login_after_hours_All_user'),
    path('mubina_after_hour_Device_connects_All_users/', views.mubina_after_hour_Device_connects_All_users, name='mubina_after_hour_Device_connects_All_users'),
    path('mubina_logon_on_weekends/', views.mubina_logon_on_weekends, name='mubina_logon_on_weekends'),
    path('samra/', views.samra, name='samra'),
    path('ali/', views.ali, name='ali'),
    path('samar/', views.samar, name='samar'),
    path('samar_RNN/', views.samar_RNN, name='samar'),
    path('mubinatask1/', views.mubinatask1, name='mubinatask1'),
    path('ann/', views.samra_ann, name='samra'),
    path('samra_Auto_email_mp/', views.samra_Auto_email_mp, name='samra_Auto_email_mp'),
    path('view_pdf_samra_Auto_email_mp/', views.view_pdf_samra_Auto_email_mp, name='view_pdf'),
    path('ANN_KDE_KNN_Analysis_Report/', views.view_pdf_mubina_ANN_KDE_KNN_Analysis_Report, name='view_pdf_mubina_ANN_KDE_KNN_Analysis_Report'),

 path('mubina_after_hour_emails_all_users/', views.mubina_after_hour_emails_all_users, name='mubina'),
]

