from django.conf import settings
from django.http import HttpResponse, FileResponse
from django.shortcuts import render
import os

# from nbconvert import HTMLExporter
# import nbformat


# def hello_view(request):
#     return HttpResponse("Hello, World!")

# def index(request):
#     return render(request, 'index.html')

def index(request):
    return render(request, 'index.html')

def mubina(request):
    return render(request, 'mubina.html')
def samra(request):
    return render(request, 'samra.html')
def ali(request):
    return render(request, 'ali.html')
def samar(request):
    return render(request, 'samar.html')
def mubinatask1(request):
    return render(request, 'mubinatask1.html')


def samra_ann(request):
    return render(request, 'samra_ANN.html')
def samra_Auto_email_mp(request):
    return render(request, 'samra_Auto_email_mp.html')
def samar_RNN(request):
    return render(request, 'samar_RNN.html')
def mubina_Login_after_hours_All_user(request):
    return render(request, 'mubina_Login_after_hours_All_user.html')
def mubina_after_hour_Device_connects_All_users(request):
    return render(request, 'mubina_after_hour_Device_connects_All_users.html')
def mubina_logon_on_weekends(request):
    return render(request, 'mubina_logon_on_weekends.html')




def mubina_after_hour_emails_all_users(request):
    return render(request, 'mubina_after_hour_emails_all_users.html')

def view_pdf_samra_Auto_email_mp(request):
    pdf_path = os.path.join(settings.BASE_DIR, 'media', 'MatrxProfile&Ann.pdf')
    if os.path.exists(pdf_path):
        with open(pdf_path, 'rb') as pdf:
            response = HttpResponse(pdf.read(), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename="MatrxProfile&Ann.pdf"'
            return response
    else:
        return HttpResponse("The PDF file does not exist.")
    
def view_pdf_mubina_ANN_KDE_KNN_Analysis_Report(request):
    pdf_path = os.path.join(settings.BASE_DIR, 'media', 'ANN_KDE_KNN_Analysis_Report.pdf')
    if os.path.exists(pdf_path):
        with open(pdf_path, 'rb') as pdf:
            response = HttpResponse(pdf.read(), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename="ANN_KDE_KNN_Analysis_Report.pdf"'
            return response
    else:
        return HttpResponse("The PDF file does not exist.")
    
    
    
    # def show_pdf(request):
    # filepath = os.path.join('static', 'sample.pdf')
    # return FileResponse(open(filepath, 'rb'), content_type='application/pdf')
    
    
# import pdfkit
# def my_view(request):
#     # URL to the PDF file
#     pdf_url = '/media/MatrxProfile&Ann.pdf'

#     # Render the template with the PDF file URL in the context
#     return render(request, 'samra.html', {'pdf_url': pdf_url})
    
    # def pdf_view(request):
    # with open('E:\mypdf.pdf', 'rb') as pdf:
    #     response = HttpResponse(pdf.read(), content_type='application/pdf')
    #     response['Content-Disposition'] = 'inline;filename=mypdf.pdf'
    #     return response

# def notebook_view(request):
#     with open('/notebooks/daily_analysis_all_users.ipynb') as f:
#         nb = nbformat.read(f, as_version=4)
#         html_exporter = HTMLExporter()
#         body, resources = html_exporter.from_notebook_node(nb)
#     return render(request, 'notebook.html', {'body': body})
# from django.http import HttpResponse
# from notebook.services.contents.filemanager import FileContentsManager
# from notebook.services.kernels.kernelmanager import MappingKernelManager
# from notebook.notebookapp import NotebookApp
# from notebook.utils import url_path_join

# def start_kernel(request):
#     cm = FileContentsManager()
#     km = MappingKernelManager()
#     kernel_id = km.start_kernel().id
#     nb_app = NotebookApp(contents_manager=cm, kernel_manager=km, kernel_id=kernel_id)
#     base_url = url_path_join(request.path, 'notebooks')
#     nb_app.initialize(argv=['--no-browser', '--notebook-dir', '.', '--NotebookApp.base_url=%s' % base_url])
#     nb_app.start()
#     return HttpResponse()